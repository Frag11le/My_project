document.querySelectorAll(".dropdown__simplebar").forEach(dropdown => {
  new SimpleBar(dropdown, {
    /* чтобы изначально ползунок был виден */
    autoHide: false,
    /* с помощью этого значения вы можете управлять высотой ползунка*/
    scrollbarMaxSize: 25,
  });
})


const btns = document.querySelectorAll(".menu__btn");
const dropdowns = document.querySelectorAll(".dropdown");
const activeClassdropdowns = "dropdown__active";
const activeClassbtns = "btn__active";

btns.forEach(item => {
  item.addEventListener("click", function () {
    let DropThis = this.parentElement.querySelector(".dropdown");
    dropdowns.forEach(el => {
      if (el != DropThis) {
        el.classList.remove(activeClassdropdowns)
      }
    });
    btns.forEach(el => {
      if (el != this) {
        el.classList.remove(activeClassbtns)
      }
    });
    DropThis.classList.toggle(activeClassdropdowns);
    this.classList.toggle(activeClassbtns);
  })
})

const container = document.querySelector(".container")
const swiper = new Swiper('.swiper', {
  // Default parameters
  slidesPerView: 1,
  spaceBetween: 10,
  speed: 2000,
  autoplay: {
    delay: 2000
  },
  effect: "fade",
  allowTouchMove: false,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev"
  },
  pagination: {
    el: '.swiper-bullet-pagination',
    type: 'bullets',
    clickable: true
  }

})

const element = document.querySelector('.select');
const choices = new Choices(element, {
  duplicateItemsAllowed: false,
  allowHTML: true,
  searchEnabled: false,
  placeholder: false,
  itemSelectText: '',
  shouldSort: false,
});

document.addEventListener("DOMContentLoaded", () => {
  let gallerySlider = new Swiper(".slides-container", {
    grid: {
      rows: 1,
      fill: "row"
    },
    spaceBetween: 20,
    pagination: {
      el: ".test-section .test-pagination",
      type: "fraction"
    },
    navigation: {
      nextEl: ".test-next",
      prevEl: ".test-prev"
    },

    breakpoints: {
      320: {
        slidesPerGroup: 1,
        slidesPerView: 1,
        spaceBetween: 30
      },
      430: {
        slidesPerGroup: 2,
        slidesPerView: 2,
        spaceBetween: 30
      },

      1675: {
        slidesPerGroup: 3,
        slidesPerView: 3,
        spaceBetween: 50
      }
    },

    a11y: false,
    keyboard: {
      enabled: true,
      onlyInViewport: true
    }, // можно управлять с клавиатуры стрелками влево/вправо

    // Дальнейшие надстройки делают слайды вне области видимости не фокусируемыми
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    slideVisibleClass: "slide-visible",

    on: {
      init: function () {
        this.slides.forEach((slide) => {
          if (!slide.classList.contains("slide-visible")) {
            slide.tabIndex = "-1";
          } else {
            slide.tabIndex = "";
          }
        });
      },
      slideChange: function () {
        this.slides.forEach((slide) => {
          if (!slide.classList.contains("slide-visible")) {
            slide.tabIndex = "-1";
          } else {
            slide.tabIndex = "";
          }
        });
      }
    }

    // on: {
    //   /* исправляет баг с margin-top остающимся при смене брейкпоинта, это было нужно в 6-й версии свайпера */
    //   beforeResize: function () {
    //     this.slides.forEach((el) => {
    //       el.style.marginTop = "";
    //     });
    //   }
    // }
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const accordion = document.querySelectorAll('.accordion');

  accordion.forEach(el => {
    el.addEventListener('click', (e) => {
      const self = e.currentTarget;
      const control = self.querySelector('.accordion-control');
      const content = self.querySelector('.accordion-content');

      if (self.contains(e.target) && e.target.classList.contains('accordion-control')) {
        self.classList.toggle('open');

        if (self.classList.contains('open')) {
          content.style.maxHeight = content.scrollHeight + 'px';
        } else {
          content.style.maxHeight = null;
        }
      }
    });
  });
});


document.addEventListener("DOMContentLoaded", () => {
  let eventSlider = new Swiper(".swiper-event", {

    breakpoints: {
      320: {
        slidesPerGroup: 1,
        slidesPerView: 1,
        spaceBetween: 50
      },
      677: {
        slidesPerGroup: 2,
        slidesPerView: 2,
        spaceBetween: 27
      },
      768: {
        slidesPerGroup: 2,
        slidesPerView: 2,
        spaceBetween: 34
      },
      1000: {
        slidesPerGroup: 3,
        slidesPerView: 3,
        spaceBetween: 27
      },
      1500: {
        slidesPerGroup: 3,
        slidesPerView: 3,
        spaceBetween: 50
      }


    },

    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev"
    },

    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
  });
});

document.addEventListener("DOMContentLoaded", () => {
  let eventSlider = new Swiper(".swiper-project", {

    slidesPerView: 3,
    slidesPerGroup: 1,
    spaceBetween: 30,

    breakpoints: {
      320: {
        slidesPerView: 1,
        slidesPerGroup: 1,
        spaceBetween: 0,
      },
      600: {
        slidesPerView: 2,
        slidesPerGroup: 2,
        spaceBetween: 15,
      },
      1200: {
        slidesPerView: 3,
        slidesPerGroup: 3,
        spaceBetween: 30,
      }

    },

    navigation: {
      nextEl: ".swiper-buton-next",
      prevEl: ".swiper-buton-prev"
    },
  });
});

new window.JustValidate('.form', {
  rules: {
    name: {
      required: true,
      minLength: 2,
      maxLength: 20,
    },
    tel: {
      required: true,
      function: (name, value) => {
        const phone = value.replace(/\D+/g, '');
        return phone.length === 11;
      }
    }
  },
  messages: {
    name: {
      required: 'Пожалуйста, введите ваше имя',
      minLength: 'Имя должно содержать не менее 2 символов',
      maxLength: 'Имя должно содержать не более 20 символов',
    },
    tel: {
      required: 'Пожалуйста, введите ваш номер телефона',
      function: 'Номер телефона должен содержать 11 цифр'
    }
  }
});

ymaps.ready(init);
function init() {

  var myMap = new ymaps.Map("map", {
    center: [55.758468, 37.6010884],

    zoom: 14,
    controls: []

  });



  var myPlacemark = new ymaps.Placemark([55.758468, 37.6010884], {}, {
    iconLayout: 'default#image',
    iconImageHref: 'img/map/point.png',
    iconImageSize: [20, 20],
    iconImageOffset: [-3, -42]

  });

  myMap.geoObjects.add(myPlacemark);
}


// const labels = document.querySelectorAll('.form-label');
// labels.forEach((label) => {
//   label.addEventListener('keydown', (event) => {
//     if (event.code === 'Enter') {
//       const checkbox = label.querySelector('.checkbox');
//       checkbox.click();
//     }
//   });
// });

tippy('.my-button', {
  content: 'а что тут нужно писать?',
  animation: 'scale',
  placement: 'bottom',
});

const tabItems = document.querySelectorAll('.catalog-list-item');
const tabContentItems = document.querySelectorAll('.tab-content');

// Add click event listener to each tab item
tabItems.forEach(item => {
  item.addEventListener('click', () => {
    // Remove active class from all tab items and content items
    tabItems.forEach(item => {
      item.classList.remove('active');
    });
    tabContentItems.forEach(item => {
      item.classList.remove('active');
    });

    // Add active class to clicked tab item and corresponding content item
    const target = item.getAttribute('data-tab-target');
    item.classList.add('active');
    document.querySelector(target).classList.add('active');
  });
});

document.addEventListener('DOMContentLoaded', function () {
  var burgerMenu = document.querySelector('.burger-menu');
  var body = document.querySelector('body');

  burgerMenu.addEventListener('click', function () {
    burgerMenu.classList.toggle('active');
    body.classList.toggle('menu-open');
  });
});

var openBtn = document.getElementById("openBtn");
var closeBtn = document.getElementById("closeBtn");
var searchBox = document.getElementById("searchBox");

openBtn.addEventListener("click", function () {
  searchBox.classList.remove("hidden");
});

closeBtn.addEventListener("click", function () {
  searchBox.classList.add("hidden");
});

const searchHeader = document.querySelector(".search-header");

openBtn.addEventListener("click", () => {
  searchHeader.classList.add("tranX"); // Add the "tranX" class to the search-header element
});

closeBtn.addEventListener("click", () => {
  searchHeader.classList.remove("tranX"); // Remove the "active" class from the search-header element
});

